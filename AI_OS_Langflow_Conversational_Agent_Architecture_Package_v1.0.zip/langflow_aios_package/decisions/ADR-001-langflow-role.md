# ADR-001：Langflow 在 AI OS 中的角色

- **狀態**：Proposed
- **日期**：2026-08-08
- **決策者**：AI OS Architecture Review Board（待指定）
- **適用版本**：Langflow 1.11.x；AI OS 架構提案 v1.0

## Context

AI OS 希望讓企業使用者以「教新員工」的對話方式替 Agent 增加收信、分類、查 CRM、使用知識庫、排程與核准等能力。Langflow 原生提供視覺化 Flow、Agent、Tool Mode、MCP client/server、Knowledge Base、Memory Base、HITL、API、Langflow Assistant 與 Custom Component 等建構元素，但沒有完整的企業級「對話教學 → 可版本化 Skill → 測試 → 核准 → 發布 → 回滾」控制平面。

## Decision

採用 **AI OS Control Plane + Langflow Subordinate Engine**：

1. AI OS 是 Agent、Skill、Tool/MCP、Policy、Knowledge binding、部署版本與 Audit 的唯一真實來源。
2. Skill 先表示為引擎中立的 Skill IR；Compiler 再將其轉成受控的 Langflow Flow artifact。
3. 所有 Langflow API、Flow JSON、run/event/HITL resume 差異由 `LangflowRuntimeAdapter` 隔離。
4. Langflow IDE/Assistant 只用於 Authoring 與受控管理員工作，不直接成為一般企業使用者的主要 UX。
5. Worker Agent 不得自我修改 Production Skill；任何教學都先建立 Change Proposal。
6. LLM 生成的 Python/Custom Component 不得直接進入 Production；必須經 sandbox、靜態掃描、測試、人工核准與不可變映像重建。
7. Authoring/Sandbox 與 Production Runtime 分開部署，正式憑證只由 Runtime 透過 Vault/KMS 的短期授權取得。
8. 保留 Engine Adapter，使未來可替換成 LangGraph、自研 Runtime 或混合執行。

## Alternatives considered

### A. 直接把 Langflow 當完整產品與真實來源

優點是最快；缺點是業務資料模型被 Flow JSON 綁定、Skill/版本/核准與多租戶治理不足，且 Runtime 替換成本高。**不採用。**

### B. AI OS Control Plane + Langflow Runtime（本決策）

平衡速度、治理、可替換性與視覺化開發效率。**採用。**

### C. Langflow 僅作原型工具，正式 Runtime 完全自研

控制力高，但初期開發成本較高。保留為成熟期演進路徑。

### D. 不使用 Langflow，直接使用 LangGraph 或自研

對複雜長任務有潛力，但會失去快速視覺化建構與既有元件生態。除非 POC 證明 Langflow Adapter 無法滿足可靠度或隔離要求，否則暫不採用。

## Consequences

### Positive

- 使用者看到的是一致的對話式 Agent Builder，而不是 Langflow Canvas。
- Skill 可測試、可審批、可回滾，且能跨 Runtime。
- 降低 Langflow v2 Beta API 或 Flow JSON 變更對產品核心的影響。
- 安全邊界明確，避免 LLM 直接取得 Production 修改權。

### Negative

- 必須自行開發 Skill Registry、Builder/Compiler、Policy/Approval、Adapter 與 Evaluation Harness。
- Skill IR 與 Flow Compiler 需持續維護 mapping 與 contract tests。
- Langflow 部分原生功能可能與 AI OS 功能重疊，需要明確界定責任。

## Validation

以「Read-only 櫃檯收信 Agent」作 POC。只有在下列條件成立時才轉入正式開發：

- 對話可產生結構化 Skill 草稿與可閱讀 diff。
- 退款與外寄場景必定 HITL；提示注入不能擴權。
- 執行可追蹤、冪等、可重播；Langflow artifact 可回滾。
- Langflow 版本升級由 Adapter contract tests 隔離。
