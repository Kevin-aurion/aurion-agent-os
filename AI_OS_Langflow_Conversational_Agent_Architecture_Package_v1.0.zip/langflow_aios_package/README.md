# AI OS × Langflow 對話式 Agent Builder 架構包

這個資料夾是一份可同時供人員與 AI OS 讀取的開發／架構規格。核心結論不是「直接把 Langflow 當成 AI OS」，而是讓 AI OS 擁有企業治理控制平面，並透過 Adapter 把 Langflow 當成可替換的 Flow Authoring 與 Runtime Engine。

## 建議閱讀順序

1. `AI_OS_Langflow_Conversational_Agent_Architecture_v1.0.md`
2. `decisions/ADR-001-langflow-role.md`
3. `schemas/skill.schema.json`
4. `examples/front_desk_email_skill.yaml`
5. `api/openapi-draft.yaml`
6. `checklists/integration_assessment.yaml`

## 最重要的設計限制

- Worker Agent 不得直接修改 Production Skill 或 Flow。
- 對話教學先產生 Change Proposal；通過測試與核准後才發布。
- Skill 是結構化、可版本化、可測試、可授權、可回滾的規格，不是單純 Prompt 或 Memory。
- Langflow 不持有 AI OS 的唯一真實資料；Flow JSON 只是編譯產物。
- Authoring/Sandbox 與 Production Runtime 分離。
- 未受信任或 LLM 生成的 Python/Custom Component 不可直接進正式環境。

## 文件狀態

本文件未讀取目前 AI OS 原始碼、資料庫 schema 或部署設定，因此「是否能融合」必須使用 `checklists/integration_assessment.yaml` 對實際專案逐項比對。架構已刻意採用 Adapter 與中介規格，降低既有技術棧差異。

## 驗證結果

- Word 文件已完整渲染檢查，共 61 頁，未發現裁切、重疊或表格溢位。
- Word 無障礙稽核：high 0、medium 0、low 0；明細見 `a11y_audit.json`。
- 所有 YAML 檔案均可解析。
- `schemas/skill.schema.json` 符合 JSON Schema Draft 2020-12，且範例 Skill 已通過驗證。
- 檔案雜湊見 `SHA256SUMS.txt`。
